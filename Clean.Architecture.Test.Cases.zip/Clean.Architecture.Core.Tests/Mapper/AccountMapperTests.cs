using Xunit;
using Clean.Architecture.Core.Common.Mapper;
using Clean.Architecture.Core.Common.Request;
using Clean.Architecture.Core.Common.Response;
using Clean.Architecture.Core.Entities.Buisness;

public class AccountMapperTests
{
    [Fact]
    public void MapToAccount_NullRequest_ReturnsNullAccount()
    {
        // Arrange
        AccountRequest request = null;

        // Act
        var account = AccountMapper.MapToAccount(request);

        // Assert
        Assert.Null(account);
    }

    [Fact]
    public void MapToAccountResponse_NullAccount_ReturnsNullAccountResponse()
    {
        // Arrange
        Account account = null;

        // Act
        var accountResponse = AccountMapper.MapToAccountResponse(account);

        // Assert
        Assert.Null(accountResponse);
    }

    [Fact]
    public void MapToAccountResponse_NullProperties_ReturnsAccountResponseWithDefaultValues()
    {
        // Arrange
        var account = new Account(); // Account object with all properties set to default values

        // Act
        var accountResponse = AccountMapper.MapToAccountResponse(account);

        // Assert
        Assert.NotNull(accountResponse);
        Assert.Equal(default(int), accountResponse.CustomerId);
        Assert.Null(accountResponse.AccountType);
        Assert.Null(accountResponse.AccountNumber);
        Assert.Null(accountResponse.BranchAddress);
    }
}

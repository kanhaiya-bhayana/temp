using Xunit;
using Moq;
using Clean.Architecture.Core.Accounts.Commands.Create;
using Clean.Architecture.Core.Interfaces;
using Clean.Architecture.Core.Common.Interfaces.Authentication;
using Clean.Architecture.Core.Common.Response;
using System;

public class CreateAccountCommandHandlerTests
{
    [Fact]
    public async Task Handle_ValidCommand_AddsAccountAndGeneratesToken()
    {
        // Arrange
        var unitOfWorkMock = new Mock<IUnitOfWork>();
        var jwtTokenGeneratorMock = new Mock<IJwtTokenGenerator>();

        var handler = new CreateAccountCommandHandler(unitOfWorkMock.Object, jwtTokenGeneratorMock.Object);
        var command = new CreateAccountCommand(new AccountRequestDto());

        // Act
        var response = await handler.Handle(command, CancellationToken.None);

        // Assert
        unitOfWorkMock.Verify(uow => uow.AccountRepository.AddAsync(It.IsAny<Account>()), Times.Once);
        jwtTokenGeneratorMock.Verify(jwt => jwt.GenerateToken(It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>()), Times.Once);
        Assert.NotNull(response);
        Assert.True(response.Success);
    }

    [Fact]
    public async Task Handle_NullCommand_ThrowsArgumentNullException()
    {
        // Arrange
        var unitOfWorkMock = new Mock<IUnitOfWork>();
        var jwtTokenGeneratorMock = new Mock<IJwtTokenGenerator>();

        var handler = new CreateAccountCommandHandler(unitOfWorkMock.Object, jwtTokenGeneratorMock.Object);

        // Act & Assert
        await Assert.ThrowsAsync<ArgumentNullException>(() => handler.Handle(null, CancellationToken.None));
    }

    // Additional test cases for other scenarios can be written similarly...
}

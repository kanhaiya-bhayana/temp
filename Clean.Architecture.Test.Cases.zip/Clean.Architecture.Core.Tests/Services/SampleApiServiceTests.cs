using Xunit;
using Moq;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
using Clean.Architecture.Core.Services.Interfaces;
using Clean.Architecture.Core.Services.Implementation;

public class SampleApiServiceTests
{
    [Fact]
    public async Task GetProductsAsync_ReturnsSampleProduct()
    {
        // Arrange
        var httpClientFactoryMock = new Mock<IHttpClientFactory>();
        var httpClientMock = new Mock<HttpClient>();
        var sampleProduct = new SampleProduct { Id = 1, Name = "Product 1", Price = 10.99 };

        httpClientFactoryMock.Setup(factory => factory.CreateClient(It.IsAny<string>())).Returns(httpClientMock.Object);
        httpClientMock.Setup(client => client.GetFromJsonAsync<SampleProduct>(It.IsAny<string>())).ReturnsAsync(sampleProduct);

        var sampleApiService = new SampleApiService(httpClientFactoryMock.Object);

        // Act
        var result = await sampleApiService.GetProductsAsync();

        // Assert
        Assert.NotNull(result);
        Assert.Equal(sampleProduct.Id, result.Id);
        Assert.Equal(sampleProduct.Name, result.Name);
        Assert.Equal(sampleProduct.Price, result.Price);
    }

    [Fact]
    public async Task GetProductsAsync_ThrowsException_WhenHttpClientFails()
    {
        // Arrange
        var httpClientFactoryMock = new Mock<IHttpClientFactory>();
        var httpClientMock = new Mock<HttpClient>();

        httpClientFactoryMock.Setup(factory => factory.CreateClient(It.IsAny<string>())).Returns(httpClientMock.Object);
        httpClientMock.Setup(client => client.GetFromJsonAsync<SampleProduct>(It.IsAny<string>())).ThrowsAsync(new HttpRequestException());

        var sampleApiService = new SampleApiService(httpClientFactoryMock.Object);

        // Act & Assert
        await Assert.ThrowsAsync<HttpRequestException>(() => sampleApiService.GetProductsAsync());
    }

    [Fact]
    public async Task GetProductsAsync_ReturnsNull_WhenApiResponseIsNull()
    {
        // Arrange
        var httpClientFactoryMock = new Mock<IHttpClientFactory>();
        var httpClientMock = new Mock<HttpClient>();

        httpClientFactoryMock.Setup(factory => factory.CreateClient(It.IsAny<string>())).Returns(httpClientMock.Object);
        httpClientMock.Setup(client => client.GetFromJsonAsync<SampleProduct>(It.IsAny<string>())).ReturnsAsync((SampleProduct)null);

        var sampleApiService = new SampleApiService(httpClientFactoryMock.Object);

        // Act
        var result = await sampleApiService.GetProductsAsync();

        // Assert
        Assert.Null(result);
    }
}

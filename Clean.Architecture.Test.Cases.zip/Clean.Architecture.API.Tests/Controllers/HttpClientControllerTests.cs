using Xunit;
using Moq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Clean.Architecture.Core.Services.Interfaces;
using Clean.Architecture.Core.Common.Response;
using Clean.Architecture.API.Controllers;

public class HttpClientControllerTests
{
    private readonly Mock<ISampleApiService> _mockSampleApiService;
    private readonly HttpClientController _controller;

    public HttpClientControllerTests()
    {
        _mockSampleApiService = new Mock<ISampleApiService>();
        _controller = new HttpClientController(_mockSampleApiService.Object);
    }

    [Fact]
    public async Task GetProducts_ReturnsSampleProduct()
    {
        // Arrange
        var expectedProduct = new SampleProduct { Id = 1, Name = "Product1", Price = 10.0M };
        _mockSampleApiService.Setup(service => service.GetProductsAsync())
                             .ReturnsAsync(expectedProduct);

        // Act
        var result = await _controller.GetProducts();

        // Assert
        Assert.NotNull(result);
        Assert.Equal(expectedProduct.Id, result?.Id);
        Assert.Equal(expectedProduct.Name, result?.Name);
        Assert.Equal(expectedProduct.Price, result?.Price);
    }

    [Fact]
    public async Task GetProducts_ReturnsNull_WhenNoProductFound()
    {
        // Arrange
        _mockSampleApiService.Setup(service => service.GetProductsAsync())
                             .ReturnsAsync((SampleProduct?)null);

        // Act
        var result = await _controller.GetProducts();

        // Assert
        Assert.Null(result);
    }
}

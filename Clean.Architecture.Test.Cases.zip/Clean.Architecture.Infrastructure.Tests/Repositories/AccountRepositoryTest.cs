using Xunit;
using Moq;
using System;
using System.Linq;
using System.Data;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Dapper;
using Clean.Architecture.Core.Entities.Buisness;
using Clean.Architecture.Infrastructure.Repositories;
using System.Collections.Generic;

public class AccountRepositoryTests
{
    private readonly Mock<IConfiguration> _mockConfiguration;
    private readonly Mock<IDbConnection> _mockDbConnection;
    private readonly AccountRepository _accountRepository;

    public AccountRepositoryTests()
    {
        _mockConfiguration = new Mock<IConfiguration>();
        _mockConfiguration.Setup(config => config.GetConnectionString(It.IsAny<string>())).Returns("TestConnectionString");

        _mockDbConnection = new Mock<IDbConnection>();

        _accountRepository = new AccountRepository(_mockConfiguration.Object)
        {
            ConnectionFactory = () => _mockDbConnection.Object
        };
    }

    [Fact]
    public async Task GetAllAsync_ShouldReturnAllAccounts()
    {
        // Arrange
        var accounts = new List<Account>
        {
            new Account { AccountNumber = 1, CustomerId = 1, AccountType = "Savings", BranchAddress = "Branch 1" },
            new Account { AccountNumber = 2, CustomerId = 2, AccountType = "Checking", BranchAddress = "Branch 2" }
        };

        _mockDbConnection.SetupDapperAsync(c => c.QueryAsync<Account>(It.IsAny<string>(), null, null, null, null))
            .ReturnsAsync(accounts);

        // Act
        var result = await _accountRepository.GetAllAsync();

        // Assert
        Assert.NotNull(result);
        Assert.Equal(accounts.Count, result.Count);
        Assert.Equal(accounts, result);
    }

    [Fact]
    public async Task GetByIdAsync_ShouldReturnAccount_WhenAccountExists()
    {
        // Arrange
        var account = new Account { AccountNumber = 1, CustomerId = 1, AccountType = "Savings", BranchAddress = "Branch 1" };

        _mockDbConnection.SetupDapperAsync(c => c.QuerySingleOrDefaultAsync<Account>(It.IsAny<string>(), It.IsAny<object>(), null, null, null))
            .ReturnsAsync(account);

        // Act
        var result = await _accountRepository.GetByIdAsync(1);

        // Assert
        Assert.NotNull(result);
        Assert.Equal(account.AccountNumber, result.AccountNumber);
    }

    [Fact]
    public async Task GetByIdAsync_ShouldThrowException_WhenAccountNotExists()
    {
        // Arrange
        _mockDbConnection.SetupDapperAsync(c => c.QuerySingleOrDefaultAsync<Account>(It.IsAny<string>(), It.IsAny<object>(), null, null, null))
            .ReturnsAsync((Account)null);

        // Act & Assert
        await Assert.ThrowsAsync<Exception>(() => _accountRepository.GetByIdAsync(1));
    }

    [Fact]
    public async Task AddAsync_ShouldAddAccount()
    {
        // Arrange
        var account = new Account { CustomerId = 1, AccountType = "Savings", BranchAddress = "Branch 1", CreatedAt = DateTime.Now };

        _mockDbConnection.SetupDapperAsync(c => c.ExecuteAsync(It.IsAny<string>(), It.IsAny<object>(), null, null, null))
            .ReturnsAsync(1);

        // Act
        await _accountRepository.AddAsync(account);

        // Assert
        _mockDbConnection.Verify(c => c.ExecuteAsync(AccountQueries.AddAccount, account, null, null, null), Times.Once);
    }

    [Fact]
    public async Task UpdateAsync_ShouldUpdateAccount()
    {
        // Arrange
        var account = new Account { AccountNumber = 1, CustomerId = 1, AccountType = "Savings", BranchAddress = "Branch 1", UpdatedAt = DateTime.Now };

        _mockDbConnection.SetupDapperAsync(c => c.ExecuteAsync(It.IsAny<string>(), It.IsAny<object>(), null, null, null))
            .ReturnsAsync(1);

        // Act
        await _accountRepository.UpdateAsync(account);

        // Assert
        _mockDbConnection.Verify(c => c.ExecuteAsync(AccountQueries.UpdateAccount, account, null, null, null), Times.Once);
    }

    [Fact]
    public async Task DeleteAsync_ShouldDeleteAccount_WhenAccountExists()
    {
        // Arrange
        _mockDbConnection.SetupDapperAsync(c => c.ExecuteAsync(It.IsAny<string>(), It.IsAny<object>(), null, null, null))
            .ReturnsAsync(1);

        // Act
        await _accountRepository.DeleteAsync(1);

        // Assert
        _mockDbConnection.Verify(c => c.ExecuteAsync(AccountQueries.DeleteAccount, It.IsAny<object>(), null, null, null), Times.Once);
    }

    [Fact]
    public async Task DeleteAsync_ShouldThrowException_WhenAccountNotExists()
    {
        // Arrange
        _mockDbConnection.SetupDapperAsync(c => c.ExecuteAsync(It.IsAny<string>(), It.IsAny<object>(), null, null, null))
            .ReturnsAsync(0);

        // Act & Assert
        await Assert.ThrowsAsync<Exception>(() => _accountRepository.DeleteAsync(1));
    }
}

public static class MoqDapperExtensions
{
    public static ISetup<IDbConnection, Task<IEnumerable<T>>> SetupDapperAsync<T>(this Mock<IDbConnection> mockDbConnection,
        Func<IDbConnection, Task<IEnumerable<T>>> setup)
    {
        return mockDbConnection.Setup(d => setup(d));
    }

    public static ISetup<IDbConnection, Task<T>> SetupDapperAsync<T>(this Mock<IDbConnection> mockDbConnection,
        Func<IDbConnection, Task<T>> setup)
    {
        return mockDbConnection.Setup(d => setup(d));
    }

    public static ISetup<IDbConnection, Task<int>> SetupDapperAsync(this Mock<IDbConnection> mockDbConnection,
        Func<IDbConnection, Task<int>> setup)
    {
        return mockDbConnection.Setup(d => setup(d));
    }
}
